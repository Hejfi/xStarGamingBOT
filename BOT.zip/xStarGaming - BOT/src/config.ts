export let config = {
    "token": "NTU2NzQ3MjM2NzM4ODU5MDEw.D2-SnA.dIiy8xMwljp-vljn_ZkV_eKc_W0",
    "prefix": "!",
    "commands": [
        "testCommand",
    ]
}